function extract(){
    traveller.budget = document.getElementById("budget").value;
    traveller.where = document.getElementById("destination").value;
    traveller.start_date = document.getElementById("begin-date").value;
    traveller.end_date = document.getElementById("end-date").value;
}